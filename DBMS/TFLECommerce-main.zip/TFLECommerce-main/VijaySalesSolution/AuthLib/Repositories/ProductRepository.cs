﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AuthLib.Entities;

namespace AuthLib.Repositories
{
    public  class ProductRepository
    {
        public List<Product> GetAllAvailableProducts()
        {
            List<Product> products = new List<Product>();
            //
            return products;
        }
    }
}
