
using ShoppingStoreApp.Server.Repositories.Interfaces;
namespace ShoppingStoreApp.Server.Services.Interfaces;
public interface IProductService : IProductRepository
{
}