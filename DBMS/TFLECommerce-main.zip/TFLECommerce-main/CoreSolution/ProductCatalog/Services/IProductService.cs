
using  Transflower.ECommerce.ProductCatalog.Repositories.Interfaces;
namespace Transflower.ECommerce.ProductCatalog.Services.Interfaces;
public interface  IProductService : IProductRepository
{

}