using System.ComponentModel;
using Transflower.ECommerce.HR.Repositories.Interfaces;

namespace Transflower.ECommerce.HR.Services.Interfaces;

public interface IMembershipService:IMembershipRepository{

}