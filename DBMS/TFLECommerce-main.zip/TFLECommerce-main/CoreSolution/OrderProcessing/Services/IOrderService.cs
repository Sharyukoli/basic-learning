using  Transflower.ECommerce.OrderProcessing.Repositories.Interfaces;
namespace Transflower.ECommerce.OrderProcessing.Services.Interfaces;
public interface  IOrderService : IOrderRepository
{

}