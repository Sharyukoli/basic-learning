using Transflower.ECommerce.Entities;
using Transflower.ECommerce.Repositories.Interfaces;
namespace Transflower.ECommerce.Services.Interfaces;
public interface IPeopleService:IPeopleRepository{

}