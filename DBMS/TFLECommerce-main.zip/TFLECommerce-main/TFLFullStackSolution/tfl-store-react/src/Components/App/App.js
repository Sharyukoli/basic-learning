
import Login from '../../Components/Login/Login'
import './App.css';

function App() {
  return (
            <div>
                <div class="container mt-5">
                    <div class="row">
                        <div class="col-sm-4">
                        <Login></Login>
                        </div>
                        <div class="col-sm-8">
                        <h2>TFL Assessment Protal</h2>      
                <ol>
                  <li>Online Practical Test</li>
                  <li>Multiple Choice Questions</li>
                  <li>Group Discussion</li>
                </ol>
                        </div>
                    </div>
                </div>
            </div>
  );
}
export default App;