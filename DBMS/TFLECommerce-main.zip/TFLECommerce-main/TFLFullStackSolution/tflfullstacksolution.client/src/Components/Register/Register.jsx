function Register() {
  return (
    <p>Hello world!</p>
  );
}

export default Register;