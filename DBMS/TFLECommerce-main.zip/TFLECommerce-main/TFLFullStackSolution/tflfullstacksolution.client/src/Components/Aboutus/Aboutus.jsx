 import './Aboutus.css';
function Aboutus() {
    return (
        <div>
            <h1 id="tableLabel">About Us</h1>
            <ol>
                <li>Training Company</li>
                <li>Online live mentoring</li>
                <li>Project Based Learning</li>
                <li>Transflower Acceleration Program</li>
            </ol>  
        </div>
    );
}
export default Aboutus;