﻿namespace FirstWebApp.Models
{
    public class Customer
    {
        public string Name {  get; set; }
        public string Email { get; set; }
        public string ContactNumber {  get; set; }
    }
}
